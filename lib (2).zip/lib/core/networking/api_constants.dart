class ApiConstants {
  static final baseApiUrl = 'http://10.0.2.2:8002';

  //  for mobile
  //  static final baseApiUrl = 'http://10.166.0.234:8000';
}
