class Routes {
  static const String onbordingScreen = '/onbordingScreen';
  static const String homeScreen = '/homeScreen';
  static const String loginScreen = '/loginScreen';
  static const String getStartScreen = '/getStartScreen';
  static const String pagesMyApp = '/pagesMyApp';
  static const String profileScreen = '/profileScreen';
  static const String settingsScreen = '/settingsScreen';
  static const String registerScreen = '/registerScreen';
  static const String otpScreen = '/otpScreen';
  static const String walletsScreen = '/walletsScreen';
  static const String transactionHistoryScreen = '/transactionHistoryScreen';
  static const String transferScreen = '/transferScreen';
  static const String topupScreen = '/topupScreen';
  static const String currencyexchangescreen = '/currencyExhangeScreen';
  static const String withdrawfundsscreen = '/withdrawFundsScreen';
  static const String billpaymentsscreen = '/billPaymentsScreen';
  static const String selectproviderscreen = '/selectProviderScreen';
  static const String billpaymentdetailsscreen = '/billPaymentDetailsScreen';
  static const String profilescreen = '/ProfileScreen';
  static const String editprofilescreen = '/editProfileScreen';
}
