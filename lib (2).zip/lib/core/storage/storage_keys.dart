abstract class StorageKeys {
  static const String token = 'token';
  static const String user = 'user';
}
